using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DilogueDict : MonoBehaviour {
	Dictionary<int, Dilogue> introConvDilogue;
	Dictionary<int, Dilogue> clickOnPerogi;
	Dictionary<int, Dilogue> clickOnAnna;
	Dictionary<int, Dilogue> clickOnFish;
	Dictionary<int, Dilogue> sushiDesc0;
	Dictionary<int, Dilogue> sushiDesc1;
	Dictionary<int, Dilogue> sushiDesc2;
	Dictionary<int, Dilogue> sushiDesc3;	
	Dictionary<int, Dilogue> sushiDesc4;
	Dictionary<int, Dilogue> sushiDesc5;	
	Dictionary<int, Dilogue> sushiDesc6;
	Dictionary<int, Dilogue> sushiDesc7;	
	Dictionary<int, Dilogue> sushiDesc8;
	Dictionary<int, Dilogue> sushiDesc9;						
	Dictionary<int, Dilogue>[] clickOnMatrix;
	Dictionary<int, Dilogue>[] sushiMatrix;
//0 = clickOnText
//1 = sushi Anlayze text
//2 = sushi Eat text
//3 = customer Eat text
//4 = intro stuff
	public Dictionary<int, Dilogue> getDilogue (int indexType, int i) {
		if (indexType == 0) {
			return clickOnMatrix[i];
			// if (i == 0) {
			// 	return clickOnPerogi;
			// }
			// else if (i == 1) {
			// 	return clickOnAnna;
			// }
			// else if (i == 2) {
			// 	return clickOnFish;
			// }						
			//return clickOnMatrix[i];
		}
		if (indexType == 1) {
			return clickOnMatrix[i];
		}
		if (indexType == 2) {

			return sushiMatrix[1];
		}		
		if (indexType == 4) {
			return introConvDilogue;
			//Debug.Log("FUCK YEAH");
		}
		return clickOnFish;
	}
	
	public void Awake() {
		introConvDilogue = new Dictionary<int, Dilogue>();
		clickOnPerogi = new Dictionary<int, Dilogue>();
		clickOnAnna = new Dictionary<int, Dilogue>();
		clickOnFish = new Dictionary<int, Dilogue>();
		sushiDesc0 = new Dictionary<int, Dilogue>();
		sushiDesc1 = new Dictionary<int, Dilogue>();
		sushiDesc2 = new Dictionary<int, Dilogue>();
		sushiDesc3 = new Dictionary<int, Dilogue>();	
		sushiDesc4 = new Dictionary<int, Dilogue>();
		sushiDesc5 = new Dictionary<int, Dilogue>();
		sushiDesc6 = new Dictionary<int, Dilogue>();
		sushiDesc7 = new Dictionary<int, Dilogue>();		
		sushiDesc8 = new Dictionary<int, Dilogue>();
		sushiDesc9 = new Dictionary<int, Dilogue>();			
		Dilogue introConv0 = new Dilogue() {
			ID = 0,
		 	text0 = "",
		 	text1 = "HELLO! I am Liza, first name Anna",
		 	text2  = ""
		};
		Dilogue introConv1 = new Dilogue() {
			ID = 1,
		 	text0 = "",
		 	text1 = "Get it?",
		 	text2  = ""
		};
		Dilogue introConv2 = new Dilogue() {
			ID = 2,
		 	text0 = "(Christ, these damn chatbots taking the jobs of good hard working photocopiers)",
		 	text1 = "Cause I’m an analyzer, and the language processing program ELIZA?",
		 	text2 = ""
		};
		Dilogue introConv3 = new Dilogue() {
			ID = 3,
		 	text0 = "(Clicking on her dialogue should speed this up...)",
		 	text1 = "Cause I’m an analyzer, and the language processing program ELIZA?",
		 	text2 = ""
		};	
		introConvDilogue.Add(introConv0.ID, introConv0);
		introConvDilogue.Add(introConv1.ID, introConv1);
		introConvDilogue.Add(introConv2.ID, introConv2);
		introConvDilogue.Add(introConv3.ID, introConv3);

		Dilogue perogi0 = new Dilogue() {
			ID = 0,
		 	text0 = "(It's myself. Not one for long monologuing, although if I were",
		 	text1 = "",
		 	text2  = ""
		};
		Dilogue perogi1 = new Dilogue() {
			ID = 1,
		 	text0 = "I'd start my story one dark and rainy night",
		 	text1 = "",
		 	text2  = ""
		};
		Dilogue perogi2 = new Dilogue() {
			ID = 2,
		 	text0 = "A call comes in on the phone...)",
		 	text1 = "",
		 	text2  = ""
		};						
		clickOnPerogi.Add(perogi0.ID, perogi0);
		clickOnPerogi.Add(perogi1.ID, perogi1);
		clickOnPerogi.Add(perogi2.ID, perogi2);			

		Dilogue anna0 = new Dilogue() {
			ID = 0,
		 	text0 = "",
		 	text1 = "Hello! Anna here. Again!",
		 	text2  = ""
		};		
		clickOnAnna.Add(anna0.ID, anna0);

		Dilogue fish0 = new Dilogue() {
			ID = 0,
		 	text0 = "",
		 	text1 = "",
		 	text2  = "Fishy! Fish fish fishy!"
		};		
		clickOnFish.Add(fish0.ID, fish0);


		Dilogue sushi0 = new Dilogue() {
			ID = 0,
		 	text0 = "Tastes pretty good.",
		 	text1 = "A piece of fish, covered in rice, wrapped in seaweed. Classic.",
		 	text2 = "Thank you."
		};	
		Dilogue sushi1 = new Dilogue() {
			ID = 0,
		 	text0 = "Tastes pretty good.",
		 	text1 = "By simply cutting up a roll, it becomes a whole new food.",
		 	text2 = "Thank you."
		};
		Dilogue sushi2 = new Dilogue() {
			ID = 0,
		 	text0 = "I mean it's sushi, yes. I can find you the nearest dictionary if you need one.", 
		 	text1 = "Tastes pretty good.",
		 	text2 = "Thank you."
		};
		Dilogue sushi3 = new Dilogue() {
			ID = 0,
		 	text0 = "Contents: crab, rice. Trace amounts of stick.",  
		 	text1 = "Kinda the one's in the freezer, only twice the price.",
		 	text2 = "Thank you."
		};
		Dilogue sushi4 = new Dilogue() {
			ID = 0,
		 	text0 = "Their triangular shape suggests tricep digited designed this food.",  
		 	text1 = "Mmm.",
		 	text2 = "Thank you."
		};	
		Dilogue sushi5 = new Dilogue() {
			ID = 0,
		 	text0 = "Contents: 5g sodium, 3g carbohydrates, 2g sugar. Not a significant source of fat.",  
		 	text1 = "Filling, although hopefully not to the point of transferring it's namesake to you.",
		 	text2 = "Thank you."
		};	
		Dilogue sushi6 = new Dilogue() {
			ID = 0,
		 	text0 = "I have compiled the data after countless coruntines;down to 2 bytes of data: Seaweed & rice.",  
		 	text1 = "Oddly refreshing to have something not predicated on fish genocide.",
		 	text2 = "Thank you."
		};
		Dilogue sushi7 = new Dilogue() {
			ID = 0,
		 	text0 = "Naturally cylindrical when found in nature,;these rolls have been compacted into cubes for ease of transport",  
		 	text1 = "The shape does not however correspond to your esophagus. Almost choked!",
		 	text2 = "Thank you."
		};
		Dilogue sushi8 = new Dilogue() {
			ID = 0,
		 	text0 = "Conforms to the recently published theory of reality;being based on a series of descending hexagonal shapes.",  
		 	text1 = "Kinda tastes like eat a part of the world,;but better than the dirt that would entail.",
		 	text2 = "Thank you."
		};	
		Dilogue sushi9 = new Dilogue() {
			ID = 0,
		 	text0 = "Conforms to the recently published theory of reality;being based on a series of descending hexagonal shapes.",  
		 	text1 = "Kinda tastes like eat a part of the world,;but better than the dirt that would entail.",
		 	text2 = "Thank you."
		};		
		sushiDesc0.Add(sushi0.ID, sushi0);
		sushiDesc1.Add(sushi1.ID, sushi1);
		sushiDesc2.Add(sushi2.ID, sushi2);
		sushiDesc3.Add(sushi3.ID, sushi3);
		sushiDesc4.Add(sushi4.ID, sushi4);
		sushiDesc5.Add(sushi5.ID, sushi5);
		sushiDesc6.Add(sushi6.ID, sushi6);
		sushiDesc7.Add(sushi7.ID, sushi7);
		sushiDesc8.Add(sushi8.ID, sushi8);
		sushiDesc9.Add(sushi9.ID, sushi9);	
		//Debug.Log(sushiMatrix [0]);
	 	sushiMatrix = new Dictionary<int, Dilogue>[10];
		sushiMatrix [0] = sushiDesc0;
		sushiMatrix [1] = sushiDesc1;
		sushiMatrix [2] = sushiDesc2;
		sushiMatrix [3] = sushiDesc3;
		sushiMatrix [4] = sushiDesc4;
		sushiMatrix [5] = sushiDesc5;
		sushiMatrix [6] = sushiDesc6;
		sushiMatrix [7] = sushiDesc7;
		sushiMatrix [8] = sushiDesc8;
		sushiMatrix [9] = sushiDesc9;
		clickOnMatrix = new Dictionary<int, Dilogue>[3];
		clickOnMatrix [0] = clickOnPerogi;
		clickOnMatrix [1] = clickOnAnna;
		clickOnMatrix [2] = clickOnFish;																																					
	}
}
public class Dilogue
	{
		public int ID {get; set;}
		public string text0 {get; set;}
		public string text1 {get; set;}
		public string text2 {get; set;}		
	}

	// dictonaryDilogue.Add(0, "", "HELLO! I am Liza, first name Anna", "");
		// dictonaryDilogue.Add(1, "", "Get it?", "");
		// dictonaryDilogue.Add(2, "(Christ, these damn chatbots taking the jobs of good hard working photocopiers)", "Cause I’m an analyzer, and the language processing program ELIZA?");
		// dictonaryDilogue.Add(3, "(Clicking on her dialogue should speed this up...)", "", "Which had a script called DOCTOR that could respond to questions and was one of the first chatterbots.");					
