using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SushiScript : MonoBehaviour {
	public Collider2D col;
	public string labelName;
	public int indexNumber;
	public bool moveable = true;
	public int assignedPerson;
	void Start () {
	 	col = GetComponent<BoxCollider2D>();
	}
}
