﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EmptySpots : MonoBehaviour {
	public int endPoint;
	public bool onBelt;
	public bool occupant;
	public int spotID;

	void Update () {
		if(onBelt==true) {
			transform.Translate(new Vector3(-1,0,0) * Time.deltaTime);
			if(transform.position.x < endPoint) {
				Destroy(gameObject);
			}
		}
	}
}
