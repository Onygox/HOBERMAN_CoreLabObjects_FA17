using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; 

public class SushiMaker : MonoBehaviour {


    public bool draggingItem = false;
    public GameObject draggedObject;
    public Text actionTextBox;
    public string actionString;
    private Vector2 touchOffset;
    public GameObject sushi; 
    public GameObject emptyPlace;
    public Sprite[] spriteList;
    float sushiTimer;
    public GameObject belt;
    bool beltMake;
    int diceRoll;
    int tenRoll;
    int lineRoll;
    int chanceNothing = 1;
    int chanceGreen = 10;
    int chanceYellow = 0;
    int chancePurple = 0;
    int chanceBlue = 0;
    int chanceRed = 0;
    int chanceDarkRed = 0;
    public bool hasInput = false;
    string interaction;
    public GameObject eatingObject;
    public List<SushiClass> sushiList;
    void Start () {
        sushiList = GetComponent<SushiList>().sushiList;
    }

    void Update () {
        if (Input.GetMouseButtonDown(0)) {
            hasInput = !hasInput;
        }
        sushiTimer += Time.deltaTime;
        if(hasInput) {
            DragOrPickUp();
            if(draggingItem == false) {
                hasInput = !hasInput;
            }
        }
        else if (!hasInput && draggingItem == true) {
            DropItem();
        }
        if(sushiTimer >= 1) {
            GameObject sushiNew = Instantiate(sushi, transform.position, transform.rotation);
            SpriteRenderer spriteRenderer = sushiNew.GetComponent<SpriteRenderer>();
            GameObject opening = Instantiate(emptyPlace, transform.position, transform.rotation);
            sushiNew.gameObject.transform.SetParent(opening.gameObject.transform);
            SushiScript sushiNewScript = sushiNew.GetComponent<SushiScript>();
            if (lineRoll == 0) {
                diceRoll = Random.Range(1, chanceNothing + chanceGreen + chanceYellow + chanceBlue + chancePurple + chanceRed + chanceDarkRed);
                tenRoll = Random.Range(0,9);
                lineRoll = Random.Range(1,4);
            }
            else {
                lineRoll --;
            }
            sushiNewScript.indexNumber = tenRoll;
            if (diceRoll <= chanceNothing) {
                sushiNew.transform.parent = null;
                Destroy(sushiNew);
            }
            else if (diceRoll >= chanceNothing && diceRoll <= chanceNothing + chanceGreen) {
                spriteRenderer.sprite = spriteList[tenRoll];
            }

            if(beltMake==true) {
                Instantiate(belt, transform.position + (transform.right*0.5f), transform.rotation);
                beltMake=false;
            }
            else { 
                beltMake = true;
            }
            sushiTimer = 0;
        }

        var inputPosition = CurrentTouchPosition;
        RaycastHit2D[] touches = Physics2D.RaycastAll(inputPosition, inputPosition, 0.5f);
        if (draggingItem) {
             //SushiScript sushiScript = draggedObject.GetComponent<SushiScript>();
             //actionString = sushiScript.labelName;
            if (touches.Length > 0)
            {
                var hit = touches[0];
                if (hit.transform.gameObject.tag == "Sushi")
                {
                    SushiScript sushiScript = hit.transform.gameObject.GetComponent<SushiScript>();
                    interaction = "Swap with";
                    actionString = sushiList[sushiScript.indexNumber].name;
                }
                if (hit.transform.gameObject.tag == "Person") {
                    PersonScript customerScript = hit.transform.gameObject.GetComponent<PersonScript>();
                    actionString = customerScript.personName; ///, " ", draggedObject
                    interaction = "Give to";
                }
            }
            else {
                actionString = "";
            }
        }
        else {
            if (touches.Length > 0)
            {
                var hit = touches[0];
                if (hit.transform.gameObject.tag == "Sushi")
                {
                    SushiScript sushiScript = hit.transform.gameObject.GetComponent<SushiScript>();
                    interaction = "Pick up";
                   actionString = sushiList[sushiScript.indexNumber].name;
                }
                if (hit.transform.gameObject.tag == "Person") {
                    PersonScript customerScript = hit.transform.gameObject.GetComponent<PersonScript>();
                    actionString = customerScript.personName;
                    interaction = "Talk to";
                }
                if (hit.transform.gameObject.tag == "Menu") {
                    actionString = "Menu";
                    interaction = "Look at";
                }
            }
            else {
                actionString = "";
            }
        }
        if (actionString == "") {
            actionTextBox.text = "";
        }
        else {
            actionTextBox.text = interaction + " " + actionString;
        }
    }

    Vector2 CurrentTouchPosition
    {
        get
        {
            Vector2 inputPos;
            inputPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            return inputPos;
        }
    }
 
    private void DragOrPickUp()
    {
        var inputPosition = CurrentTouchPosition;
     
        if (draggingItem)
        {
            draggedObject.transform.position = inputPosition + touchOffset;
        }
        else
        {
            RaycastHit2D[] touches = Physics2D.RaycastAll(inputPosition, inputPosition, 0.5f);
            if (touches.Length > 0)
            {
                var hit = touches[0];
                if (hit.transform != null && hit.transform.gameObject.tag == "Sushi")
                {
                    //SushiScript sushiScript = hit.transform.gameObject.GetComponent<SushiScript>();
                    draggedObject = hit.transform.gameObject;
                    touchOffset = (Vector2)hit.transform.position - inputPosition;
                    draggedObject.transform.localScale = new Vector3(1.2f,1.2f,1.2f);
                    draggingItem = true;
                    draggedObject.transform.parent = null;
                    draggedObject.GetComponent<SpriteRenderer>().sortingOrder = 3;
                    draggedObject.layer = 2;
                    //  if(sushiScript.assignedPerson != 0) {
                    //     if(sushiScript.assignedPerson == 3) {
                    //         self.GetComponent<PersonScript>().gift(0,0);
                    //         sushiScript.assignedPerson = 0;
                    //     }
                    // }
                }
            }
        }
    }

    void DropItem()
    {
        //SushiScript sushiScript = draggedObject.GetComponent<SushiScript>();
        draggingItem = false;
        draggedObject.transform.localScale = new Vector3(1f,1f,1f);
        GameObject nearVacant = FindClosestEmpty();
        int indexingNumber = draggedObject.GetComponent<SushiScript>().indexNumber;
        int vacantID = nearVacant.GetComponent<EmptySpots>().spotID;
        if (vacantID != 5) {
           // sushiScript.assignedPerson = vacantID;
            bool[] personBool = new bool[] {false, false, false};
            personBool[vacantID] = true;
            GetComponent<CentralPersonScript>().talk(2, indexingNumber, personBool);
        }   
        draggedObject.transform.position = nearVacant.gameObject.transform.position;
        draggedObject.gameObject.transform.SetParent(nearVacant.gameObject.transform);
        draggedObject.GetComponent<SpriteRenderer>().sortingOrder = 0;
        draggedObject.layer = 0;
        draggedObject = null;
    }

    public GameObject FindClosestEmpty()
    {
        GameObject[] gos;
        gos = GameObject.FindGameObjectsWithTag("Empty");
        GameObject closest = null;
        float distance = Mathf.Infinity;
        Vector3 position = draggedObject.transform.position;
        foreach (GameObject go in gos)
        {
            Vector3 diff = go.transform.position - position;
            float curDistance = diff.sqrMagnitude;
            if (curDistance < distance && go.transform.childCount == 0)
            {
                closest = go;
                distance = curDistance;
            }
        }
        return closest;
    }
}


