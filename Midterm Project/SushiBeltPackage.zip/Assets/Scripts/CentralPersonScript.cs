﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CentralPersonScript : MonoBehaviour {
    public GameObject SushiMaker;
	public List<SushiClass> sushiList;
   // public Queue<string> q = new Queue<string>();
    public DescriptionScript[] descScripts;
    public GameObject[] people;
    public DilogueDict diction;
  //  public bool[] currentTalking;
    public bool[] currentTalking;
    public bool[] whoShouldTalk;
    public bool checkBool = true;
	int dilogueInt;
	public Dictionary<int, Dilogue> words;

	void Start () {
		for(int i=0;i<descScripts.Length;i++) {
			descScripts[i] = people[i].GetComponent<DescriptionScript>();
		}
		sushiList = SushiMaker.GetComponent<SushiList>().sushiList;
		diction = GetComponent<DilogueDict>();
//	currentTalking = new bool[3];
		currentTalking = new bool[3];
		whoShouldTalk = new bool[3] {false, false, false};
		Debug.Log (currentTalking.Length);
		// for (int i = 0; i <currentTalking.Length;i++) {
		// 	currentTalking[i] = true;
		// }
		// talk(4, 0);

	}

	public void talk (int indexType, int indexSpec, bool[] who) {
		if (checkBool == true && words == null) {
			// bool check = true;
			 Debug.Log( who[0]);
			Debug.Log( who[1]);
			Debug.Log( who[2]);
			// for (int i = 0; i < who.Length; i++) {
			// 	if (who[i] == true && currentTalking[i] == true) {
			// 		check = false;
			// 	}
			// }
			for (int z = 0; z < whoShouldTalk.Length; z++) {
				whoShouldTalk[z] = who[z];
			}
						 Debug.Log( whoShouldTalk[0]);
			Debug.Log( whoShouldTalk[1]);
			Debug.Log( whoShouldTalk[2]);
			words = diction.getDilogue(indexType, indexSpec);
			nextTalk ();			
		}
	}

	// public void foodDesc (int indexID, int spotPoint) {
	// 	if (checkBool == true && words == null) {
	// 		words = diction.getDilogue(2, 0);
	// 		for (int i = 0; i < currentTalking.Length; i++) {
	// 			currentTalking[i] = false;
	// 		}
	// 		if (words.Count == dilogueInt) {
	// 			words = null;
	// 			dilogueInt = 0;
	// 			descScripts[0].NewerText("");
	// 			descScripts[1].NewerText("");
	// 			descScripts[2].NewerText("");
	// 		}
	// 		else {
	// 			Dilogue currentWords = words[indexID];
	// 			if (spotPoint == 0) {
	// 				descScripts[spotPoint].NewerText(currentWords.text0);
	// 			}
	// 			if (spotPoint == 1) {
	// 				descScripts[spotPoint].NewerText(currentWords.text1);
	// 			}	
	// 			if (spotPoint == 2) {
	// 				descScripts[spotPoint].NewerText(currentWords.text1);
	// 			}							
	// 			dilogueInt++;
	// 		}
	// 	}
	// }	
//states: no talk, talking, done talking

	public void nextTalk () {
		if (words.Count == dilogueInt) {
			words = null;
			dilogueInt = 0;
			for (int f = 0; f < currentTalking.Length; f++) {
				currentTalking[f] = false;
				whoShouldTalk[f] = false;
			}
			descScripts[0].NewerText("");
			descScripts[1].NewerText("");
			descScripts[2].NewerText("");
		}
		else {
			for (int i = 0; i < currentTalking.Length; i++) {
				if (whoShouldTalk[i] == true) {
					currentTalking[i] = true;
				}
			}
			Dilogue currentWords = words[dilogueInt];

			if (whoShouldTalk[0] == true) {
				descScripts[0].NewerText(currentWords.text0);
			}
			if (whoShouldTalk[1] == true) {
				descScripts[1].NewerText(currentWords.text1);
			}
			if (whoShouldTalk[2] == true) {
				descScripts[2].NewerText(currentWords.text2);
			}
			dilogueInt++;
		}

	}
///all false
	//if any of them not false, dont write
	//if they are all false write
	//
	void Update () {
		if (currentTalking[0] == true | currentTalking[1] == true | currentTalking[2] == true){
			checkBool = false;
		}
		else {
			checkBool = true;
		}
		if (checkBool == true && words != null)
		{
			nextTalk ();
		}
	}

	// public void gift (int indexID, int spotPoint) {
	// 	spotPoint--;
	// 	Queue<string> q = new Queue<string>();
	// 		string newText = "";
	// 		if (spotPoint == 0) {
	// 			newText = sushiList[indexID].EatingString;
	// 		}
	// 		else if (spotPoint == 1) {
	// 			newText = sushiList[indexID].InspectionString;
	// 		}
	// 		else if (spotPoint == 2) {
	// 			newText = sushiList[indexID].customer2String;
	// 		}			
	// 		int lastI = 0;
	// 		for (int i = 0; i < newText.Length; i ++) {
	// 				if (newText[i] == ';') {
	// 					q.Enqueue(newText.Substring(lastI, i-lastI));
	// 					lastI = i+1;
	// 			}
	// 		}
	// 		// descScripts[spotPoint].NewText(q);
	// 	}	
	// public void referBack (Queue<string> q, int person) {
	// 	Debug.Log("THis:" + q.Peek());
	// 	// descScripts[person].NewText( new Queue<string> (q));
	// }
}



		// int lastI = 0;
		// for (int i = 0; i < newText.Length; i ++) {
		// 	if (newText[i] == ';') {
		// 		q.Enqueue(newText.Substring(lastI, i-lastI));
		// 		lastI = i+1;
		// 	}
		// }