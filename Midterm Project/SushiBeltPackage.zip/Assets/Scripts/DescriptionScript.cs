﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DescriptionScript : MonoBehaviour {
    private Text text;
    public Image backDrop;
    public bool isRunning = false;
    public bool finishedText = true;
    public static float textTime = 0.1f;
    public int descIndex;
    CentralPersonScript centralScript;
    public string currentText;

	void Awake () {
		text = gameObject.GetComponent<Text>();
		centralScript = GameObject.Find("SushiMaker").GetComponent<CentralPersonScript>();
		text.enabled = false;
		finishedText = false;
		backDrop.enabled = false;
		text.text ="";
	}

	void TaskyOnClick()
    {
         if (isRunning == true) {
         	textTime = 0.01f;
         }
    }

	IEnumerator AnimateText(){
		isRunning = true; 
		string strComplete = currentText;
		int letterCount = 0;
		//char lastLetter = strComplete[strComplete.Length-1];
		foreach (char letter in strComplete.ToCharArray()) {
			text.text += letter;
			letterCount++;
			yield return new WaitForSeconds (textTime);
		}
	    isRunning = false;
	    finishedText = true;
	    textTime = 0.1f;
	    	    Debug.Log("Check1");
	    yield return new WaitForSeconds(textTime * 10);
	    centralScript.currentTalking[descIndex] = false;  
	    Debug.Log("Check2");
	}

	void Update () {
		// if (currentText == "") {
		// 	text.enabled = false;
		// 	finishedText = false;
		// 	backDrop.enabled = false;
		// }
	}
	public bool tempBool = false;

	public void NewerText (string newText) {
	 	text.text ="";
		currentText = newText;
		if(newText != "") {
			backDrop.enabled = true;
			text.enabled = true;
			StartCoroutine(AnimateText());	
		}
		else {
			text.enabled = false;
			finishedText = false;
			backDrop.enabled = false;
			centralScript.currentTalking[descIndex] = false; 	
		}		
	}
}
