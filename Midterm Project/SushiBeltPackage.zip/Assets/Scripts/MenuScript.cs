using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuScript : MonoBehaviour {
	public GameObject menu;
	public bool menuShow;
	Vector3 targetMiddle;
	Image menuSprite;
	public Sprite open;
	Sprite closed;
	Vector3 returnPosition;


	void Start () {
		targetMiddle = new Vector3 (3.5f,2.5f,0);
		menuSprite = menu.GetComponent<Image>();
		returnPosition = menu.transform.position;
		closed = menu.GetComponent<Image>().sprite;

	}

	void OnMouseDown () {
		menuShow = true;
	    }

	void Update () {
		if (menuShow == true) {
			menu.transform.position = Vector3.MoveTowards(menu.transform.position, targetMiddle, 100 * Time.deltaTime);
		}
		else if  (menuShow == false) {
			menu.transform.position = Vector3.MoveTowards(menu.transform.position, returnPosition, 100 * Time.deltaTime);
			menuSprite.sprite = closed;
		}
		if (menu.transform.position == targetMiddle) {
			menuSprite.sprite = open;
			menu.GetComponent<MenuUIScript>().iconShow = true;
			Image[] menuImages = menu.GetComponent<MenuUIScript>().imageIcons;
			Text[] menuText = menu.GetComponent<MenuUIScript>().textIcons;			
		for (int f = 0; f < menuImages.Length; f++)
 		{	
 			menuImages[f].enabled = true;
 			menuText[f].enabled = true;
		}
		}
		// else {
		// 	foreach (GameObject obj in menu.GetComponent<MenuUIScript>().icons)
 	// 		{
  //     		// obj.GetComponent<Image>().enabled = false;
		// // 	}
		// }
	}
}
