using System.Collections;
using System;
using UnityEngine;

	public class SushiClass
	{
		public string name;
		public string InspectionString;
		public string EatingString;
		public string customer2String;

		public SushiClass(string newName, string newInspectionString, string newEatingString, string newCustomer2String) {
			name = newName;
			InspectionString = newInspectionString + ";";
			EatingString = newEatingString + ";";
			customer2String = newCustomer2String + ";";
		}
	}
