﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeltMove : MonoBehaviour {

//public Vector3 startPoint;
public int endPoint;
	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
				transform.Translate(new Vector3(-1,0,0) * Time.deltaTime);
				 // if ((Vector3.Distance(transform.position, endPoint)) < .01f) {
				if(transform.position.x < endPoint) {
					Destroy(gameObject);
				
			
				}
	}
}
