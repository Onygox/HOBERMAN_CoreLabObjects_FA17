﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PersonScript : MonoBehaviour {
	public string personName;
	public string greetingText;
	public string clickOnText;
	public GameObject eatSpot;
    public GameObject textGameObject;
   // DescriptionScript descriptionScript;
    public Color textColor;
    GameObject SushiMaker;
	public List<SushiClass> sushiList;
	CentralPersonScript centralScript;

	void OnMouseDown () {
		//centralScript.gift(10, eatSpot.GetComponent<EmptySpots>().spotID);
		bool[] personBool = new bool[] {true, true, true};
       // personBool[eatSpot.GetComponent<EmptySpots>().spotID] = true;
		if (SushiMaker.GetComponent<SushiMaker>().draggedObject == false) {
			centralScript.talk(0, eatSpot.GetComponent<EmptySpots>().spotID, personBool);
		}
	}
	void Start () {
		SushiMaker = GameObject.Find("SushiMaker");
		//descriptionScript = textGameObject.GetComponent<DescriptionScript>();
		textGameObject.GetComponent<Text>().color = textColor;
		sushiList = SushiMaker.GetComponent<SushiList>().sushiList;
		centralScript = SushiMaker.GetComponent<CentralPersonScript>();

	}
	// public void gift (int indexID) {
	// 	if (personName == "Anna") {
	// 		descriptionScript.NewText(sushiList[indexID].InspectionString);
	// 	}
	// 	else if (personName == "Perogi") {
	// 		descriptionScript.NewText(sushiList[indexID].EatingString);
	// 	}
	// 	else if (personName == "Fishman") {
	// 		descriptionScript.NewText(sushiList[indexID].customer2String);

	// 	}	
	// }
}

