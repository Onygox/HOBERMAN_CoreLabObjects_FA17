﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SushiList : MonoBehaviour {
	public List<SushiClass> sushiList;

	void Awake () {
	    sushiList = new List<SushiClass>();
        sushiList.Add (new SushiClass 
        (
        "sushi roll", 
        "A piece of fish, covered in rice, wrapped in seaweed. Classic.", 
        "Tastes pretty good.",
        "Thank you."
        ));
        sushiList.Add (new SushiClass 
        (
        "sushi rolls", 
        "By simply cutting up a roll, it becomes a whole new food.", 
        "Tastes pretty good.",
        "Thank you."
        ));
        sushiList.Add (new SushiClass 
        (
        "salmon sushi", 
        "I mean it's sushi, yes.;I can find you the nearest dictionary if you need one.", 
        "One bite, whole lot of flavor.",
        "Thank you."
        ));
        sushiList.Add (new SushiClass 
        (
        "crab stick sushi", 
        "Contents: crab, rice. Trace amounts of stick.", 
        "Kinda the one's in the freezer, only twice the price.",
        "Thank you."
        ));
        sushiList.Add (new SushiClass 
        (
        "handrolls", 
        "Their triangular shape suggests tricep digited designed this food.", 
        "Mmm.",
        "Thank you."
        ));     
        sushiList.Add (new SushiClass 
        (
        "fat rolls", 
        "Contents: 5g sodium, 3g carbohydrates, 2g sugar.;Not a significant source of fat.", 
        "Filling, although hopefully not to the point of transferring it's namesake to you.",
        "Thank you."
        ));
        sushiList.Add (new SushiClass 
        (
        "tiny rolls", 
        "Their tiny size is making it hard to pinpoint their location in space; and thus poses no threat.", 
        "It took four rolls before you had enough matter to form an opinion.;Bland.",
        "Thank you."
        ));
        sushiList.Add (new SushiClass 
        (
        "onigiri", 
        "I have compiled the data after countless coruntines;down to 2 bytes of data:;Seaweed & rice.", 
        "Oddly refreshing to have something not predicated on fish genocide.",
        "Thank you."
        ));
        sushiList.Add (new SushiClass 
        (
        "square roll", 
        "Naturally cylindrical when found in nature,;these rolls have been compacted into cubes for ease of transport", 
        "The shape does not however correspond to your esophagus.;Almost choked!",
        "Thank you."
        ));
        sushiList.Add (new SushiClass 
        (
        "hexagon roll", 
        "Conforms to the recently published theory of reality;being based on a series of descending hexagonal shapes.", 
        "Kinda tastes like eat a part of the world,;but better than the dirt that would entail.",
        "Thank you."
        ));
        sushiList.Add (new SushiClass 
        (
        "hexagon roll", 
         "HELLO! I am Liza, first name Anna. Get it?;Cause I’m an analyzer, and the language processing program ELIZA?",
        "(It's myself. Not one for long monologuing, although if I were1;I'd start my story one dark and rainy night0.;A call comes in on the phone...)", 
        "Hello there, landblubber!"
        ));           	
	}	
}
