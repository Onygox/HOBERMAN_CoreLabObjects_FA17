﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuUIScript : MonoBehaviour {
	//public GameObject menuInfo;
	public GameObject menu;
	public Transform icon;
	public GameObject SushiMaker;
	public bool iconShow = false;
	public GameObject[] icons = new GameObject[10];
	public Image[] imageIcons;
	public Text[] textIcons = new Text[10];
	//public GameObject[] iconsLabels = new GameObject[10]
	public Transform iconLabel;
    public List<SushiClass> sushiList;

	void OnMouseDown () {
		//menuInfo.SetActive(false);
		menu.GetComponent<MenuScript>().menuShow = false;
		iconShow = false;
		for (int f = 0; f < imageIcons.Length; f++)
 		{	
 			imageIcons[f].enabled = false;
 			textIcons[f].enabled = false;
		}
	}
	void Start () {
		imageIcons = new Image[10];
		sushiList = SushiMaker.GetComponent<SushiList>().sushiList;
		//if (iconShow == true && iconBake == false) {
			float y= 2.815f;
			float resetingX = 0;
			for (int i = 0; i < 10; i++) {
			 	if (i >= 5) {
			 		y=1.55f;
			 		resetingX = 6.25f;
			 	}
			 	var newIcon = Instantiate(icon, new Vector3 (1f+(i*1.25f)-resetingX, y-6, 90), Quaternion.identity, gameObject.transform);
				newIcon.GetComponent<Image>().sprite = SushiMaker.GetComponent<SushiMaker>().spriteList[i];
				var newText = Instantiate(iconLabel,  new Vector3 (1f+(i*1.25f)-resetingX, y-6.65f, 90),Quaternion.identity, gameObject.transform);
				newText.GetComponent<Text>().text = sushiList[i].name;

			//newIcon.transform.parent = gameObject.transform;Camera.main.WorldToScreenPoint(new Vector3 (1,2.815,0))
			 //(i*160)
				//Debug.Log(newIcon.gameObject);
				icons[i] = newIcon.gameObject;
				//Debug.Log(i+10);
				int s = i + 10;
				icons[s] = newText.gameObject;
				//Debug.Log(icons);
				imageIcons[i] = newIcon.GetComponent<Image>();
				textIcons[i] = newText.GetComponent<Text>();
			}
			Debug.Log(imageIcons[1]);
		for (int f = 0; f < imageIcons.Length; f++)
 		{	
 			imageIcons[f].enabled = false;
 			textIcons[f].enabled = false;
		}
	}
}
